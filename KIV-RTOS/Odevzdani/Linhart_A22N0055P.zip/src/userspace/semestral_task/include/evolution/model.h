#pragma once

struct Model
{
	float A;
	float B;
	float C;
	float D;
	float E;
};