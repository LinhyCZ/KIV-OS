/mnt/c/user/privateWorkspace/School/OS/build/qemu-system-arm -M raspi0 -serial null -serial mon:stdio -kernel ../src/build/kernel.img -nographic -gdb tcp::1234
