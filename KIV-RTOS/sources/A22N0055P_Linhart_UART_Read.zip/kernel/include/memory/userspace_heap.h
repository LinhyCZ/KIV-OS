#pragma once

#include <hal/intdef.h>

// jednoduchy alokator userspace haldy pro dany proces. Nepodporuje uvolnovani jiz naalokovane pameti

class Userspace_Heap_Manager
{
    private:
        void mapToProcessMemmory(TTask_Struct* task, uint32_t physicalAddress);
        void AllocAndMapPage(TTask_Struct* task);

    public:
        Userspace_Heap_Manager();

        uint32_t sbrk(TTask_Struct* task, uint32_t size);
};

extern Userspace_Heap_Manager sUserspaceMem;