#include <process/process_manager.h>
#include <memory/userspace_heap.h>
#include <memory/pages.h>
#include <memory/mmu.h>


Userspace_Heap_Manager sUserspaceMem;

Userspace_Heap_Manager::Userspace_Heap_Manager()
{
    //
}

void Userspace_Heap_Manager::AllocAndMapPage(TTask_Struct* task) {
    uint32_t page = sPage_Manager.Alloc_Page();
    mapToProcessMemmory(task, page);

    task->heapPhysicalLimit = task->heapPhysicalLimit + mem::PageSize;
}

uint32_t Userspace_Heap_Manager::sbrk(TTask_Struct* task, uint32_t size)
{
    //Alokuj prvni stranku pokud jeste nebyla alokovana - nenastavili jsme hodnotu pro zacatek haldy
    if (task->heapStart == 0) {
        task->heapStart = mem::UserspaceHeapVirtualBase;
        AllocAndMapPage(task);
    }

    //Alokuj stranky dokud nebude dostatek mista
    while (task->heapPhysicalLimit - task->heapLogicalLimit < size) {
        AllocAndMapPage(task);
    }

    uint32_t addressToReturn = task->heapStart + task->heapLogicalLimit;
    task->heapLogicalLimit = task->heapLogicalLimit + size;

    return addressToReturn;
}

void Userspace_Heap_Manager::mapToProcessMemmory(TTask_Struct* task, uint32_t pageAddress) {   
    uint32_t physAddr = pageAddress - mem::MemoryVirtualBase;
    uint32_t userspaceVirtualAddr = task->heapStart + task->heapPhysicalLimit;

    map_memory(task->pt, physAddr, userspaceVirtualAddr);
}