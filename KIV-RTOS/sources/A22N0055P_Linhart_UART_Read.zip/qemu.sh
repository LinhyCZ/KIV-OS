./build.sh
cd userspace
./build.sh
cd ..
./build.sh

#/mnt/c/user/privateWorkspace/School/OS/build/qemu-system-arm -M raspi0 -serial null -serial mon:stdio -kernel build/kernel.img -nographic -gdb tcp::1234 -S
/mnt/c/user/privateWorkspace/School/OS/build/qemu-system-arm -M raspi0 -serial null -serial mon:stdio -kernel build/kernel.img -nographic -gdb tcp::1234
