gdb-multiarch -ex 'set architecture arm' -ex 'file build/kernel' -ex 'file userspace/build/semestral_task' -ex 'target remote tcp:localhost:1234' -ex 'layout regs'
